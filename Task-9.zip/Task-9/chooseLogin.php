<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" href="style.css">
</head>

<body class="banner">

<?php require 'resources/header.php';?>

  <div class="registration">
  <form>
   
   
   <h2 style="border: 2px solid black; margin: auto; width:190px; background-color: rgb(82, 87, 93); color: white; padding: 12px 16px;">Choose user type</h2> <br>
  <button class="choosebutton" style="border: 2px solid black;"> </i> Login as User</a></button><br><br>
  <button class="choosebutton" style="border: 2px solid black"> </i> Login as Rider</a></button><br><br>
  <button class="choosebutton" style="border: 2px solid black"> </i> Login as Medicine supplier </a></button>
   
 
</form> 
</div>

<?php require 'resources/footer.php';?>  
</body>
</html>

